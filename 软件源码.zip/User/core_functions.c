#include "system.h"

// ��ȡADC��ѹֵ
float Read_ADC_Voltage(void) {
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
    while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
    uint16_t adc_value = ADC_GetConversionValue(ADC1);
    return (float)adc_value * 3.3f / 4095.0f;
}

// У׼������
float Calibrate_Dark_Current(void) {
    float sum = 0.0f;
    for(int i = 0; i < DARK_SAMPLES; i++) {
        sum += Read_ADC_Voltage();
        Delay(10);
    }
    return sum / DARK_SAMPLES;
}
// ��ʼ���˲����������ã�
void Filter_Init(MovingAverageFilter* filter) {
    for(int i = 0; i < FILTER_WINDOW_SIZE; i++) {
        filter->buffer[i] = 0.0f;
    }
    filter->index = 0;
    filter->sum = 0.0f;
}

// �����˲����������ã�
float Filter_Update(MovingAverageFilter* filter, float newValue) {
    filter->sum -= filter->buffer[filter->index];
    filter->buffer[filter->index] = newValue;
    filter->sum += newValue;
    filter->index = (filter->index + 1) % FILTER_WINDOW_SIZE;
    return filter->sum / FILTER_WINDOW_SIZE;
}

// ����ϵͳ״̬
void System_Status_Update(float voltage) {
    static uint8_t state_counter = 0;
    
    if(voltage >= alarm_threshold) {
        if(current_state != STATE_ALARM) {
            state_counter++;
            if(state_counter >= state_change_thresh) {
                current_state = STATE_ALARM;
                state_counter = 0;
            }
        }
    } else {
        if(current_state != STATE_NORMAL) {
            state_counter++;
            if(state_counter >= state_change_thresh) {
                current_state = STATE_NORMAL;
                state_counter = 0;
            }
        }
    }
    
    // ����LED״̬
    if(current_state == STATE_NORMAL) {
        GPIO_SetBits(GREEN_LED_PORT, GREEN_LED_PIN);
        GPIO_ResetBits(RED_LED_PORT, RED_LED_PIN);
        GPIO_ResetBits(BUZZER_PORT, BUZZER_PIN); 
    } else {
        GPIO_ResetBits(GREEN_LED_PORT, GREEN_LED_PIN);
        GPIO_SetBits(RED_LED_PORT, RED_LED_PIN);
        GPIO_SetBits(BUZZER_PORT, BUZZER_PIN);
    }
}

// ����������
void Buzzer_Control(void) {
    static uint32_t next_toggle_time = 0;
    
    // ����״̬���ü��ʱ��
    uint32_t interval = (current_state == STATE_NORMAL) ? 1000 : 500;
    
    // ����Ƿ񵽴��л�ʱ��
    if(systick >= next_toggle_time) {
        // �л�������״̬
        static uint8_t beep_state = 0;
        if(beep_state == 0) {
            GPIO_SetBits(BUZZER_PORT, BUZZER_PIN);  // �ߵ�ƽ��
            next_toggle_time = systick + BUZZER_ON_TIME_MS;
            beep_state = 1;
        } else {
            GPIO_ResetBits(BUZZER_PORT, BUZZER_PIN); // �͵�ƽ����
            next_toggle_time = systick + (interval - BUZZER_ON_TIME_MS);
            beep_state = 0;
        }
    }
}

// ͨ�����ڷ���״̬
void USART_Send_Status(float avg_adc, float raw_voltage, float net_voltage) {
    char buffer[256];
    int len = snprintf(buffer, sizeof(buffer), 
        "ADC:%.1f, RawV:%.4f, NetV:%.4f, State:%s, Thr:%d, Intvl:%d, "
        "Samples:%lu, Vth:%.4f, Vdark:%.4f\r\n",
        avg_adc,
        raw_voltage,
        net_voltage,
        (current_state == STATE_NORMAL) ? "Normal" : "Alarm",
        state_change_thresh,
        sample_interval_ms,
        sample_count,
        alarm_threshold,
        v_dark);
    
    for(int i = 0; i < len; i++) {
        USART_SendData(USART2, buffer[i]);
        while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
    }
}
void Process_UART_Command(uint8_t ch) {
    static uint8_t cmd_mode = 0;
    static uint8_t buf_index = 0;
    static uint8_t uart_buf[UART_RX_BUF_SIZE];
    
    if(cmd_mode == 0) {
        // �ȴ������ַ�
        if(ch == 'T' || ch == 't') cmd_mode = 1;
        else if(ch == 'N' || ch == 'n') cmd_mode = 2;
        else if(ch == 'S' || ch == 's') cmd_mode = 3;
        else if(ch == 'I' || ch == 'i') cmd_mode = 4;
        else if(ch == 'D' || ch == 'd') cmd_mode = 5;
        else if(ch == 'W' || ch == 'w') {  // �ֶ���������
            Save_Parameters();
            USART_SendData(USART2, 'O'); // ����ȷ��
            USART_SendData(USART2, 'K');
            USART_SendData(USART2, '\r');
            USART_SendData(USART2, '\n');
        }
        buf_index = 0;
    } else {
        if(ch == '\r' || ch == '\n') {
            if(buf_index > 0) {
                uart_buf[buf_index] = '\0';
                float fval = atof((char*)uart_buf);
                uint32_t uval = atoi((char*)uart_buf);
                
                switch(cmd_mode) {
                    case 1: alarm_threshold = fval; break;
                    case 2: if(uval >= MIN_SAMPLE_COUNT && uval <= MAX_SAMPLE_COUNT) 
                              sample_count = uval; 
                            break;
                    case 3: state_change_thresh = uval; break;
                    case 4: sample_interval_ms = uval; break;
                    case 5: v_dark = fval; break;
                }
                
                // �����޸ĺ��Զ�����
                Save_Parameters();
                
                // ���ò�������
                adc_sum = 0;
                adc_sample_num = 0;
            }
            cmd_mode = 0;
        } else if(buf_index < UART_RX_BUF_SIZE-1 && (isdigit(ch) || ch == '.' || ch == '-')) {
            uart_buf[buf_index++] = ch;
        }
    }
}
// CRC32���㺯��(��ʵ��)
uint32_t Calculate_CRC(uint8_t *data, uint32_t length) {
    uint32_t crc = 0xFFFFFFFF;
    for(uint32_t i = 0; i < length; i++) {
        crc ^= data[i];
        for(uint32_t j = 0; j < 8; j++) {
            crc = (crc >> 1) ^ (0xEDB88320 & -(crc & 1));
        }
    }
    return ~crc;
}

// ���������Flash
void Save_Parameters(void) {
    FLASH_Status status;
    SystemParams system_params = {
    .magic_number = PARAM_MAGIC_NUMBER,
    .state_change_thresh = DEFAULT_STATE_CHANGE_THRESH,
    .sample_interval_ms = DEFAULT_SAMPLE_INTERVAL_MS,
    .sample_count = DEFAULT_SAMPLE_COUNT,
    .alarm_threshold = DEFAULT_ALARM_THRESHOLD,
    .v_dark = DEFAULT_V_DARK
};
    // ���²����ṹ��
    system_params.state_change_thresh = state_change_thresh;
    system_params.sample_interval_ms = sample_interval_ms;
    system_params.sample_count = sample_count;
    system_params.alarm_threshold = alarm_threshold;
    system_params.v_dark = v_dark;
    
    // ����CRC
    system_params.crc = Calculate_CRC((uint8_t*)&system_params, sizeof(SystemParams) - sizeof(uint32_t));
    
    // ����Flash
    FLASH_Unlock();
    
    // ������й���ı�־
    FLASH_ClearFlag(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPRTERR);
    
    // ��������
    status = FLASH_ErasePage(FLASH_PARAM_ADDR);
    if(status != FLASH_COMPLETE) {
        // ����ʧ�ܴ���
        FLASH_Lock();
        return;
    }
    
    // д�����
    uint32_t *src = (uint32_t*)&system_params;
    uint32_t addr = FLASH_PARAM_ADDR;
    for(uint32_t i = 0; i < sizeof(SystemParams)/4; i++) {
        status = FLASH_ProgramWord(addr, *src);
        if(status != FLASH_COMPLETE) {
            // д��ʧ�ܴ���
            break;
        }
        addr += 4;
        src++;
    }
    
    // ����Flash
    FLASH_Lock();
}

// ��Flash���ز���
void Load_Parameters(void) {
	SystemParams system_params = {
    .magic_number = PARAM_MAGIC_NUMBER,
    .state_change_thresh = DEFAULT_STATE_CHANGE_THRESH,
    .sample_interval_ms = DEFAULT_SAMPLE_INTERVAL_MS,
    .sample_count = DEFAULT_SAMPLE_COUNT,
    .alarm_threshold = DEFAULT_ALARM_THRESHOLD,
    .v_dark = DEFAULT_V_DARK
};
    SystemParams *params = (SystemParams*)FLASH_PARAM_ADDR;
    // ���ħ����CRC
    if(params->magic_number == PARAM_MAGIC_NUMBER) {
        uint32_t crc = Calculate_CRC((uint8_t*)params, sizeof(SystemParams) - sizeof(uint32_t));
        if(crc == params->crc) {
            // CRCУ��ͨ������������
            memcpy(&system_params, params, sizeof(SystemParams));
            return;
        }
    }
    
    // �������ʧ�ܣ�ʹ��Ĭ��ֵ
    system_params.magic_number = PARAM_MAGIC_NUMBER;
    system_params.state_change_thresh = DEFAULT_STATE_CHANGE_THRESH;
    system_params.sample_interval_ms = DEFAULT_SAMPLE_INTERVAL_MS;
    system_params.sample_count = DEFAULT_SAMPLE_COUNT;
    system_params.alarm_threshold = DEFAULT_ALARM_THRESHOLD;
    system_params.v_dark = DEFAULT_V_DARK;
}
