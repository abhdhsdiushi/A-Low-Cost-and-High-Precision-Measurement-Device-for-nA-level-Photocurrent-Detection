#include "system.h"

void RCC_Configuration(void) {
    // ��������ʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB |
                           RCC_APB2Periph_AFIO | RCC_APB2Periph_ADC1 |
                           RCC_APB2Periph_USART1, ENABLE);
    
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3 | RCC_APB1Periph_USART2 |
                           RCC_APB1Periph_SPI2, ENABLE);
    
    // ADCʱ������
    RCC_ADCCLKConfig(RCC_PCLK2_Div6); // ADCʱ�� = 72MHz/6 = 12MHz
}

void GPIO_Configuration(void) {
    GPIO_InitTypeDef GPIO_InitStruct;
    
    // ADC���� (PA0)
    GPIO_InitStruct.GPIO_Pin = ADC_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPD;//GPIO_Mode_IPD��������//GPIO_Mode_AINģ������
    GPIO_Init(ADC_PORT, &GPIO_InitStruct);
    
    // LED���� (PA11, PA12)
    GPIO_InitStruct.GPIO_Pin = RED_LED_PIN | GREEN_LED_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStruct);
    
    // ���������� (PA4)
    GPIO_InitStruct.GPIO_Pin = BUZZER_PIN;
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
		GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(BUZZER_PORT, &GPIO_InitStruct);
		GPIO_ResetBits(BUZZER_PORT, BUZZER_PIN); // ��ʼ�͵�ƽ����
    
    // USART2���� (PA2-TX, PA3-RX)
    GPIO_InitStruct.GPIO_Pin = USART2_TX_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
		GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(USART2_PORT, &GPIO_InitStruct);
    
    GPIO_InitStruct.GPIO_Pin = USART2_RX_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
		GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(USART2_PORT, &GPIO_InitStruct);
    
    // SPI Flash���� (PB12-CS, PB13-SCK, PB14-MISO, PB15-MOSI)
    GPIO_InitStruct.GPIO_Pin = FLASH_CS_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(FLASH_CS_PORT, &GPIO_InitStruct);
    GPIO_SetBits(FLASH_CS_PORT, FLASH_CS_PIN); // CS�ߵ�ƽ
    
    GPIO_InitStruct.GPIO_Pin = FLASH_CLK_PIN | FLASH_MOSI_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(FLASH_SPI_PORT, &GPIO_InitStruct);
    
    GPIO_InitStruct.GPIO_Pin = FLASH_MISO_PIN;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(FLASH_SPI_PORT, &GPIO_InitStruct);
}

void NVIC_Configuration(void) {
    NVIC_InitTypeDef NVIC_InitStruct;
    
    // ����TIM3�ж�
    NVIC_InitStruct.NVIC_IRQChannel = TIM3_IRQn;
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStruct);
}

void ADC_Configuration(void) {
    ADC_InitTypeDef ADC_InitStruct;
    
    ADC_InitStruct.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStruct.ADC_ScanConvMode = DISABLE;
    ADC_InitStruct.ADC_ContinuousConvMode = DISABLE;
    ADC_InitStruct.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    ADC_InitStruct.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStruct.ADC_NbrOfChannel = 1;
    ADC_Init(ADC1, &ADC_InitStruct);
    
    // ����ADCͨ��0 (PA0)
    ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_239Cycles5);
    
    // ʹ��ADC
    ADC_Cmd(ADC1, ENABLE);
    
    // У׼ADC
    ADC_ResetCalibration(ADC1);
    while(ADC_GetResetCalibrationStatus(ADC1));
    
    ADC_StartCalibration(ADC1);
    while(ADC_GetCalibrationStatus(ADC1));
}

void TIM_Configuration(void) {
    TIM_TimeBaseInitTypeDef TIM_InitStruct;
    
    // ����TIM3��Ϊϵͳ��ʱ�� (1ms�ж�)
    TIM_InitStruct.TIM_Period = 1000 - 1;      // 1ms�ж�
    TIM_InitStruct.TIM_Prescaler = 72 - 1;     // 72MHz/72 = 1MHz
    TIM_InitStruct.TIM_ClockDivision = 0;
    TIM_InitStruct.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM3, &TIM_InitStruct);
    
    // ʹ��TIM3�����ж�
    TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
    
    // ����TIM3
    TIM_Cmd(TIM3, ENABLE);
}

void USART_Configuration(void) {
    USART_InitTypeDef USART_InitStruct;
    
    // ����USART2
    USART_InitStruct.USART_BaudRate = 115200;
    USART_InitStruct.USART_WordLength = USART_WordLength_8b;
    USART_InitStruct.USART_StopBits = USART_StopBits_1;
    USART_InitStruct.USART_Parity = USART_Parity_No;
    USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStruct.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_Init(USART2, &USART_InitStruct);
    
    // ʹ��USART2�����ж�
    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
    
    // ʹ��USART2
    USART_Cmd(USART2, ENABLE);
	//�ϵ����
	const char *help_msg = 
        "Commands:\r\n"
        "T<val>: Set voltage threshold (e.g. T0.1)\r\n"
        "N<val>: Set sample count (1-10000, e.g. N500)\r\n"
        "S<val>: Set state change threshold (e.g. S3)\r\n"
        "I<val>: Set sample interval in ms (e.g. I10)\r\n"
        "D<val>: Set dark voltage (e.g. D0.02)\r\n"
        "W: Save parameters to Flash\r\n";
    
    while(*help_msg) {
        USART_SendData(USART2, *help_msg++);
        while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
    }
}

void SPI_Configuration(void) {
    SPI_InitTypeDef SPI_InitStruct;
    
    // ����SPI2
    SPI_InitStruct.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
    SPI_InitStruct.SPI_Mode = SPI_Mode_Master;
    SPI_InitStruct.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStruct.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStruct.SPI_CPHA = SPI_CPHA_1Edge;
    SPI_InitStruct.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStruct.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_8; // 9MHz (72MHz/8)
    SPI_InitStruct.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_Init(FLASH_SPI, &SPI_InitStruct);
    
    // ʹ��SPI2
    SPI_Cmd(FLASH_SPI, ENABLE);
}

// ����ʱ����
void Delay(uint32_t ms) {
    uint32_t start = systick;
    while((systick - start) < ms);
}
void Flash_Init(void) {
    // ����Flash
    FLASH_Unlock();
    
    // ����Flash�ӳ�
    FLASH_SetLatency(FLASH_Latency_2);
    
    // ʹ��Ԥȡ������
    FLASH_PrefetchBufferCmd(ENABLE);
    
    // ����Flash(ʵ��ʹ��ʱ�ٽ���)
    FLASH_Lock();
}
