#include "stm32f10x.h"                  // Device header
#include "system.h"

// ȫ�ֱ���
volatile uint32_t systick = 0;
float v_dark = DEFAULT_V_DARK;
SystemState current_state = STATE_NORMAL;
MovingAverageFilter voltage_filter;
float alarm_threshold = DEFAULT_ALARM_THRESHOLD; // ��ʼ��Ĭ����ֵ
uint8_t uart_rx_buf[UART_RX_BUF_SIZE] = {0};
uint8_t uart_rx_index = 0;
uint32_t sample_count = DEFAULT_SAMPLE_COUNT;
uint32_t adc_sum = 0;
uint32_t adc_sample_num = 0;
uint32_t state_change_thresh = DEFAULT_STATE_CHANGE_THRESH;
uint32_t sample_interval_ms = DEFAULT_SAMPLE_INTERVAL_MS;
SystemParams system_params = {
    .magic_number = PARAM_MAGIC_NUMBER,
    .state_change_thresh = DEFAULT_STATE_CHANGE_THRESH,
    .sample_interval_ms = DEFAULT_SAMPLE_INTERVAL_MS,
    .sample_count = DEFAULT_SAMPLE_COUNT,
    .alarm_threshold = DEFAULT_ALARM_THRESHOLD,
    .v_dark = DEFAULT_V_DARK
};
int main(void) {
    // Ӳ����ʼ��
    RCC_Configuration();
    GPIO_Configuration();
    NVIC_Configuration();
    ADC_Configuration();
    TIM_Configuration();
    USART_Configuration();
    SPI_Configuration();
    Flash_Init();
		// ���ر���Ĳ���
    Load_Parameters();
    // ����ȫ�ֱ���
    state_change_thresh = system_params.state_change_thresh;
    sample_interval_ms = system_params.sample_interval_ms;
    sample_count = system_params.sample_count;
    alarm_threshold = system_params.alarm_threshold;
    v_dark = system_params.v_dark;
    // ������ʱ
    for(volatile int i = 0; i < 1000000; i++);
    Calibrate_Dark_Current();
    // ��ѭ��
    while(1) {
        if(systick >= sample_interval_ms) {
            systick = 0;
            
            // �ɼ�ADCԭʼֵ
            ADC_SoftwareStartConvCmd(ADC1, ENABLE);
            while(ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == RESET);
            uint16_t adc_raw = ADC_GetConversionValue(ADC1);
            
            adc_sum += adc_raw;
            adc_sample_num++;
            
            if(adc_sample_num >= sample_count) {
                float avg_adc = (float)adc_sum / sample_count;
                float raw_voltage = avg_adc * 3.3f / 4095.0f;
                float net_voltage = raw_voltage - v_dark;
                
                System_Status_Update(net_voltage);
                USART_Send_Status(avg_adc, raw_voltage, net_voltage);
                
                adc_sum = 0;
                adc_sample_num = 0;
            }
        }
        
        if(USART_GetFlagStatus(USART2, USART_FLAG_RXNE) != RESET) {
            uint8_t ch = USART_ReceiveData(USART2);
            Process_UART_Command(ch);
        }
    }
}


