#include "system.h"

// �ض���printf��USART2
int fputc(int ch, FILE *f) {
    USART_SendData(USART2, (uint8_t)ch);
    while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
    return ch;
}

// �ض���getchar��USART2
int fgetc(FILE *f) {
    while(USART_GetFlagStatus(USART2, USART_FLAG_RXNE) == RESET);
    return USART_ReceiveData(USART2);
}
